// backend/src/db/models/Url.js (Conceptual, for ORM or direct SQL)

// Example SQL for 'Urls' table:
/*
CREATE TABLE `Urls` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `user_id` INT NOT NULL,
    `name` VARCHAR(255) NOT NULL,
    `url` VARCHAR(2048) NOT NULL,
    `type` ENUM('API', 'DOMAIN') NOT NULL,
    `monitoring_interval_minutes` INT DEFAULT 5,
    `proxy_config_id` INT NULL, -- Foreign key to ProxyConfigs
    `is_active` BOOLEAN DEFAULT TRUE,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (`user_id`) REFERENCES `Users`(`id`),
    FOREIGN KEY (`proxy_config_id`) REFERENCES `ProxyConfigs`(`id`)
);

CREATE TABLE `MonitoringLogs` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `url_id` INT NOT NULL,
    `status` ENUM('up', 'down') NOT NULL,
    `latency` INT NULL, -- in ms
    `status_code` INT NULL,
    `error` TEXT NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (`url_id`) REFERENCES `Urls`(`id`)
);

CREATE TABLE `CertificateInfo` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `url_id` INT NOT NULL UNIQUE, -- One-to-one with URL
    `expiry_date` DATE NULL,
    `days_remaining` INT NULL,
    `issuer` VARCHAR(255) NULL,
    `subject` VARCHAR(255) NULL,
    `status` ENUM('valid', 'warning', 'expired', 'error') NOT NULL,
    `error` TEXT NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (`url_id`) REFERENCES `Urls`(`id`)
);

CREATE TABLE `Users` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `username` VARCHAR(255) UNIQUE NOT NULL,
    `password` VARCHAR(255) NOT NULL, -- Hashed password
    `email` VARCHAR(255) UNIQUE NOT NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE `ProxyConfigs` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `name` VARCHAR(255) NOT NULL,
    `host` VARCHAR(255) NOT NULL,
    `port` INT NOT NULL,
    `protocol` ENUM('http', 'https', 'socks4', 'socks5') DEFAULT 'http',
    `username` VARCHAR(255) NULL,
    `password` VARCHAR(255) NULL,
    `enabled` BOOLEAN DEFAULT TRUE,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE `AlertConfigs` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `user_id` INT NOT NULL,
    `email_recipient` VARCHAR(255) NULL,
    `snmp_receiver_host` VARCHAR(255) NULL,
    `snmp_community` VARCHAR(255) NULL,
    `snmp_api_down_oid` VARCHAR(255) NULL,
    `snmp_cert_expiry_oid` VARCHAR(255) NULL,
    `cert_warning_days` INT DEFAULT 30,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (`user_id`) REFERENCES `Users`(`id`)
);
*/

// You would typically use an ORM like Sequelize to define these as JS objects:
// const { DataTypes } = require('sequelize');
// module.exports = (sequelize) => {
//     const Url = sequelize.define('Url', {
//         name: { type: DataTypes.STRING, allowNull: false },
//         url: { type: DataTypes.STRING(2048), allowNull: false },
//         type: { type: DataTypes.ENUM('API', 'DOMAIN'), allowNull: false },
//         monitoring_interval_minutes: { type: DataTypes.INTEGER, defaultValue: 5 },
//         is_active: { type: DataTypes.BOOLEAN, defaultValue: true },
//     });
//     // Define associations here, e.g., Url.belongsTo(User), Url.belongsTo(ProxyConfig)
//     return Url;
// };
