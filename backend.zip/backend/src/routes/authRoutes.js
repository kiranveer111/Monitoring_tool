// backend/src/routes/authRoutes.js
const express = require('express');
const authController = require('../controllers/authController');
const authMiddleware = require('../middleware/authMiddleware'); // Import the auth middleware

// Initialize an Express Router instance
const router = express.Router();

// Route for user registration
// POST /api/auth/register
router.post('/register', authController.register);

// Route for user login
// POST /api/auth/login
router.post('/login', authController.login);

// Route to get the authenticated user's profile
// This route is protected and requires a valid JWT
// GET /api/auth/profile
router.get('/profile', authMiddleware, authController.getProfile);

// Export the configured router
module.exports = router;
