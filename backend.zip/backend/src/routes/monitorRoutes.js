// backend/src/routes/monitoringRoutes.js
const express = require('express');
const monitoringController = require('../controllers/monitoringController');
const authMiddleware = require('../middleware/authMiddleware'); // Protect all routes

// Initialize an Express Router instance
const router = express.Router();

// All routes in this file will be protected by authentication middleware
// This ensures only authenticated users can access monitoring functionalities.
router.use(authMiddleware);

// --- URL Monitoring Routes ---

// Add a new URL for monitoring
// POST /api/monitor/urls
router.post('/urls', monitoringController.addUrl);

// Get all URLs monitored by the authenticated user
// GET /api/monitor/urls
router.get('/urls', monitoringController.getUrls);

// Update an existing URL
// PUT /api/monitor/urls/:urlId
router.put('/urls/:urlId', monitoringController.updateUrl);

// Delete a URL
// DELETE /api/monitor/urls/:urlId
router.delete('/urls/:urlId', monitoringController.deleteUrl);

// Get monitoring logs for a specific URL
// GET /api/monitor/urls/:urlId/logs
router.get('/urls/:urlId/logs', monitoringController.getMonitoringLogs);

// Get certificate information for a specific URL (domain type)
// GET /api/monitor/urls/:urlId/certificate
router.get('/urls/:urlId/certificate', monitoringController.getCertificateInfo);

// --- Proxy Configuration Routes ---

// Add a new proxy configuration
// POST /api/monitor/proxy-configs
router.post('/proxy-configs', monitoringController.addProxyConfig);

// Get all proxy configurations for the authenticated user
// GET /api/monitor/proxy-configs
router.get('/proxy-configs', monitoringController.getProxyConfigs);

// Update an existing proxy configuration
// PUT /api/monitor/proxy-configs/:proxyId
router.put('/proxy-configs/:proxyId', monitoringController.updateProxyConfig);

// Delete a proxy configuration
// DELETE /api/monitor/proxy-configs/:proxyId
router.delete('/proxy-configs/:proxyId', monitoringController.deleteProxyConfig);

// Export the configured router
module.exports = router;