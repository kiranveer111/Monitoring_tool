// backend/src/middleware/errorHandler.js
const logger = require('../utils/logger');
const AppError = require('../utils/appError'); // Custom error class

/**
 * Centralized error handling middleware for Express.
 * This function handles errors passed to `next(error)` from other middleware or route handlers.
 * It provides a consistent error response structure.
 *
 * @param {Error} err - The error object passed by `next(err)`.
 * @param {object} req - Express request object.
 * @param {object} res - Express response object.
 * @param {function} next - Express next middleware function (not used here but required for signature).
 */
module.exports = (err, req, res, next) => {
    // Default error properties
    let statusCode = err.statusCode || 500; // Use custom status code if available, else 500
    let message = err.message || 'Something went wrong!';
    let isOperational = err.isOperational || false; // Custom flag for operational errors

    // Log the error (different levels for operational vs. programming errors)
    if (isOperational) {
        logger.warn(`Operational Error: ${message} - Path: ${req.originalUrl} - IP: ${req.ip}`);
    } else {
        logger.error(`Programming Error: ${err.stack || err.message} - Path: ${req.originalUrl} - IP: ${req.ip}`);
        // For programming errors, generic message to client in production
        if (process.env.NODE_ENV === 'production') {
            message = 'Something went very wrong!'; // Don't leak internal details
        }
    }

    // Handle specific types of errors if necessary
    // Example: MySQL duplicate entry error
    if (err.code === 'ER_DUP_ENTRY') {
        statusCode = 409; // Conflict
        message = 'Duplicate entry detected. This resource already exists or violates a unique constraint.';
        isOperational = true;
    }
    // Example: JWT errors are handled in authMiddleware, but if they reach here:
    if (err.name === 'JsonWebTokenError') {
        statusCode = 401;
        message = 'Invalid token, please log in again';
        isOperational = true;
    }
    if (err.name === 'TokenExpiredError') {
        statusCode = 401;
        message = 'Your token has expired! Please log in again.';
        isOperational = true;
    }

    // Send the error response
    res.status(statusCode).json({
        status: 'error',
        statusCode: statusCode,
        message: message,
        // In development, send stack trace for debugging
        ...(process.env.NODE_ENV === 'development' && { stack: err.stack }),
    });
};
