import React from 'react';
// BrowserRouter as Router is commonly used, but for Canvas immersive immersive environment,
// it might cause issues or not render correctly. We'll use a simple
// conditional rendering based on state for page navigation for now.
// In a full local setup, you would typically use react-router-dom.
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';

// Import pages and components - FIX: Added .js extension to imports for better resolution
import LoginPage from './pages/LoginPage.js';
import DashboardPage from './pages/DashboardPage.js';
import ManageUrlsPage from './pages/ManageUrlsPage.js';
import SettingsPage from './pages/SettingsPage.js';
import Navbar from './components/Navbar.js';
import { AuthProvider, useAuth } from './context/AuthContext.js'; // AuthContext for JWT

/**
 * PrivateRoute component to protect routes.
 * Renders children only if authenticated, otherwise redirects to login.
 * @param {object} children - React children to render if authenticated.
 */
const PrivateRoute = ({ children }) => {
  const { isAuthenticated, isLoading } = useAuth();

  if (isLoading) {
    // Show a loading indicator while checking authentication status
    return (
      <div className="flex items-center justify-center min-h-screen text-xl text-gray-700">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-500"></div>
        <span className="ml-4">Loading application...</span>
      </div>
    );
  }

  // If not authenticated, redirect to login page
  return isAuthenticated ? children : <Navigate to="/login" />;
};

/**
 * Main application content component.
 * Handles routing and conditional rendering of Navbar.
 */
function AppContent() {
  const { isAuthenticated } = useAuth();

  return (
    <>
      {/* Navbar is only visible if the user is authenticated */}
      {isAuthenticated && <Navbar />}
      <div className="p-4 md:p-6 lg:p-8 flex-grow"> {/* flex-grow to push footer down */}
        <Routes>
          {/* Public route for login */}
          <Route path="/login" element={<LoginPage />} />

          {/* Protected routes */}
          <Route
            path="/dashboard"
            element={
              <PrivateRoute>
                <DashboardPage />
              </PrivateRoute>
            }
          />
          <Route
            path="/manage-urls"
            element={
              <PrivateRoute>
                <ManageUrlsPage />
              </PrivateRoute>
            }
          />
          <Route
            path="/settings"
            element={
              <PrivateRoute>
                <SettingsPage />
              </PrivateRoute>
            }
          />

          {/* Default redirect: if authenticated, go to dashboard; otherwise, go to login */}
          <Route
            path="*"
            element={isAuthenticated ? <Navigate to="/dashboard" /> : <Navigate to="/login" />}
          />
        </Routes>
      </div>
    </>
  );
}

/**
 * The root App component.
 * Wraps the application content with AuthProvider for authentication context.
 */
function App() {
  return (
    <Router>
      <AuthProvider>
        <AppContent />
      </AuthProvider>
    </Router>
  );
}

export default App;
