// backend/src/utils/logger.js
const winston = require('winston');
const config = require('../config');

// Define log levels and their colors
const levels = {
  error: 0,
  warn: 1,
  info: 2,
  http: 3,
  verbose: 4,
  debug: 5,
  silly: 6
};

const colors = {
  error: 'red',
  warn: 'yellow',
  info: 'green',
  http: 'magenta',
  verbose: 'cyan',
  debug: 'blue',
  silly: 'white'
};

// Add colors to Winston
winston.addColors(colors);

/**
 * Configures and returns a Winston logger instance.
 * Logs messages to console (with colors) and to files (error.log and combined.log).
 */
const logger = winston.createLogger({
  levels: levels, // Use custom levels
  level: config.nodeEnv === 'development' ? 'debug' : 'info', // Log level based on environment
  format: winston.format.combine(
    winston.format.timestamp({ format: 'YYYY-MM-DD HH:mm:ss' }), // Add timestamp
    winston.format.errors({ stack: true }), // Include stack trace for errors
    winston.format.splat(), // Enable string interpolation
    winston.format.json() // Output logs in JSON format for file transports
  ),
  defaultMeta: { service: 'monitoring-tool-backend' }, // Default metadata for logs
  transports: [
    // Console transport for development and general debugging
    new winston.transports.Console({
      format: winston.format.combine(
        winston.format.colorize(), // Add colors to console output
        winston.format.simple() // Simple log format for console
      ),
      level: config.nodeEnv === 'development' ? 'debug' : 'info' // Console can have a different level
    }),
    // File transport for error logs (only errors and above)
    new winston.transports.File({ filename: 'error.log', level: 'error' }),
    // File transport for all logs (info and above) - FIXED: Added 'new' keyword
    new winston.transports.File({ filename: 'combined.log' }),
  ],
  // Exit on unhandled exceptions (optional, but good for critical applications)
  exitOnError: false,
});

module.exports = logger;
