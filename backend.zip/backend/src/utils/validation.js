// backend/src/utils/validation.js
// This file contains Joi schemas for validating incoming request data.
const Joi = require('joi');

/**
 * Joi schema for user registration validation.
 * @param {object} data - The request body data to validate.
 * @returns {Joi.ValidationResult}
 */
exports.validateRegister = (data) => {
    const schema = Joi.object({
        username: Joi.string().min(3).max(30).required().messages({
            'string.min': 'Username must be at least 3 characters long.',
            'string.max': 'Username cannot exceed 30 characters.',
            'string.empty': 'Username is required.',
            'any.required': 'Username is required.'
        }),
        email: Joi.string().email().required().messages({
            'string.email': 'Please enter a valid email address.',
            'string.empty': 'Email is required.',
            'any.required': 'Email is required.'
        }),
        password: Joi.string().min(6).required().messages({
            'string.min': 'Password must be at least 6 characters long.',
            'string.empty': 'Password is required.',
            'any.required': 'Password is required.'
        }),
    });
    return schema.validate(data);
};

/**
 * Joi schema for user login validation.
 * @param {object} data - The request body data to validate.
 * @returns {Joi.ValidationResult}
 */
exports.validateLogin = (data) => {
    const schema = Joi.object({
        username: Joi.string().required().messages({
            'string.empty': 'Username is required.',
            'any.required': 'Username is required.'
        }),
        password: Joi.string().required().messages({
            'string.empty': 'Password is required.',
            'any.required': 'Password is required.'
        }),
    });
    return schema.validate(data);
};

/**
 * Joi schema for URL addition/update validation.
 * @param {object} data - The request body data to validate.
 * @param {boolean} isUpdate - True if validating for an update operation (fields can be optional).
 * @returns {Joi.ValidationResult}
 */
exports.validateUrl = (data, isUpdate = false) => {
    const schema = Joi.object({
        name: Joi.string().min(3).max(255).messages({
            'string.min': 'URL name must be at least 3 characters long.',
            'string.max': 'URL name cannot exceed 255 characters.'
        }),
        url: Joi.string().uri().max(2048).messages({
            'string.uri': 'Please enter a valid URL.',
            'string.max': 'URL cannot exceed 2048 characters.'
        }),
        type: Joi.string().valid('API', 'DOMAIN').messages({
            'any.only': 'Type must be either "API" or "DOMAIN".'
        }),
        monitoring_interval_minutes: Joi.number().integer().min(1).messages({
            'number.base': 'Monitoring interval must be a number.',
            'number.integer': 'Monitoring interval must be an integer.',
            'number.min': 'Monitoring interval must be at least 1 minute.'
        }),
        proxy_config_id: Joi.number().integer().allow(null).messages({
            'number.base': 'Proxy Config ID must be a number.',
            'number.integer': 'Proxy Config ID must be an integer.'
        }),
        is_active: Joi.boolean()
    });

    // For updates, all fields are optional. For creation, certain fields are required.
    const finalSchema = isUpdate ? schema.messages({
        'object.missing': 'At least one field (name, url, type, monitoring_interval_minutes, proxy_config_id, is_active) is required for update.'
    }).min(1) : schema.options({ presence: 'required' }); // All fields required for creation

    return finalSchema.validate(data);
};

/**
 * Joi schema for Proxy Configuration addition/update validation.
 * @param {object} data - The request body data to validate.
 * @param {boolean} isUpdate - True if validating for an update operation.
 * @returns {Joi.ValidationResult}
 */
exports.validateProxyConfig = (data, isUpdate = false) => {
    const schema = Joi.object({
        name: Joi.string().min(3).max(255).messages({
            'string.min': 'Proxy name must be at least 3 characters long.',
            'string.max': 'Proxy name cannot exceed 255 characters.'
        }),
        host: Joi.string().hostname().messages({
            'string.hostname': 'Please enter a valid hostname for the proxy host.'
        }),
        port: Joi.number().integer().min(1).max(65535).messages({
            'number.min': 'Port must be between 1 and 65535.',
            'number.max': 'Port must be between 1 and 65535.'
        }),
        protocol: Joi.string().valid('http', 'https', 'socks4', 'socks5').messages({
            'any.only': 'Protocol must be http, https, socks4, or socks5.'
        }),
        username: Joi.string().max(255).allow(null, '').messages({
            'string.max': 'Username cannot exceed 255 characters.'
        }),
        password: Joi.string().max(255).allow(null, '').messages({
            'string.max': 'Password cannot exceed 255 characters.'
        }),
        enabled: Joi.boolean()
    });

    const finalSchema = isUpdate ? schema.messages({
        'object.missing': 'At least one field (name, host, port, protocol, username, password, enabled) is required for update.'
    }).min(1) : schema.options({ presence: 'required' });

    return finalSchema.validate(data);
};

/**
 * Joi schema for Alert Configuration update validation.
 * @param {object} data - The request body data to validate.
 * @returns {Joi.ValidationResult}
 */
exports.validateAlertConfig = (data) => {
    const schema = Joi.object({
        email_recipient: Joi.string().email().allow(null, '').messages({
            'string.email': 'Please enter a valid email address for the recipient.'
        }),
        snmp_receiver_host: Joi.string().hostname().allow(null, '').messages({
            'string.hostname': 'Please enter a valid hostname for the SNMP receiver.'
        }),
        snmp_community: Joi.string().max(255).allow(null, '').messages({
            'string.max': 'SNMP community cannot exceed 255 characters.'
        }),
        snmp_api_down_oid: Joi.string().pattern(/^\.?([0-9]+\.)*[0-9]+$/).max(255).allow(null, '').messages({
            'string.pattern': 'Please enter a valid OID format.',
            'string.max': 'SNMP OID cannot exceed 255 characters.'
        }),
        snmp_cert_expiry_oid: Joi.string().pattern(/^\.?([0-9]+\.)*[0-9]+$/).max(255).allow(null, '').messages({
            'string.pattern': 'Please enter a valid OID format.',
            'string.max': 'SNMP OID cannot exceed 255 characters.'
        }),
        cert_warning_days: Joi.number().integer().min(1).max(365).messages({
            'number.base': 'Certificate warning days must be a number.',
            'number.integer': 'Certificate warning days must be an integer.',
            'number.min': 'Certificate warning days must be at least 1.',
            'number.max': 'Certificate warning days cannot exceed 365.'
        })
    });
    // For alert config, all fields are optional as user might only set some
    return schema.validate(data);
};
