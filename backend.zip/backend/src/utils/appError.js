// backend/src/utils/appError.js
/**
 * Custom error class for operational errors.
 * These are errors that are expected to happen during normal operation
 * (e.g., invalid input, resource not found, authentication failure).
 * They typically have a specific HTTP status code.
 */
class AppError extends Error {
    /**
     * Creates an instance of AppError.
     * @param {string} message - The error message.
     * @param {number} statusCode - The HTTP status code associated with the error.
     */
    constructor(message, statusCode) {
        super(message); // Call the parent Error constructor with the message

        this.statusCode = statusCode;
        this.status = `${statusCode}`.startsWith('4') ? 'fail' : 'error'; // 'fail' for 4xx, 'error' for 5xx
        this.isOperational = true; // Mark this error as an operational error

        // Capture the stack trace, excluding the constructor call itself
        Error.captureStackTrace(this, this.constructor);
    }
}

module.exports = AppError;
