// backend/src/db/connection.js
const mysql = require('mysql2/promise'); // Using 'mysql2/promise' for async/await support
const config = require('../config');
const logger = require('../utils/logger');

let pool; // Declare a variable to hold the MySQL connection pool

/**
 * Establishes a connection to the MySQL database and creates a connection pool.
 * This function should be called once when the application starts.
 * @returns {void}
 */
const connectDB = async () => {
    try {
        // Create a MySQL connection pool using configurations from config.js
        pool = mysql.createPool({
            host: config.db.host,
            user: config.db.user,
            password: config.db.password,
            database: config.db.database,
            waitForConnections: true, // Whether to wait for a connection to be available if the pool is exhausted
            connectionLimit: 10,     // Maximum number of connections in the pool
            queueLimit: 0            // Maximum number of requests the pool will queue
        });

        // Attempt to get a connection from the pool to verify connectivity
        // This will throw an error if connection fails (e.g., wrong credentials, DB not running)
        await pool.getConnection();
        logger.info('MySQL Pool created and tested successfully.');
    } catch (error) {
        // Log the error and re-throw it to indicate failure to the caller (server.js)
        logger.error(`Error connecting to MySQL: ${error.message}`);
        throw error;
    }
};

/**
 * Returns the initialized MySQL connection pool.
 * This function should be called by database models and services to execute queries.
 * @returns {mysql.Pool} The MySQL connection pool.
 * @throws {Error} If the database pool has not been initialized.
 */
const getDB = () => {
    if (!pool) {
        // Ensure connectDB has been called before attempting to get the pool
        throw new Error('Database pool not initialized. Call connectDB first.');
    }
    return pool;
};

module.exports = { connectDB, getDB };
