// backend/src/config/index.js
require('dotenv').config(); // Load environment variables from .env file

/**
 * Centralized configuration object for the backend application.
 * Reads values from environment variables, providing default fallbacks.
 */
module.exports = {
    // Server port
    port: process.env.PORT || 3000,

    // Node environment (e.g., 'development', 'production', 'test')
    nodeEnv: process.env.NODE_ENV || 'development',

    // Database configuration, loaded from database.js
    // This allows database.js to handle connection pooling and export its own configuration details.
    db: {
        host: process.env.DB_HOST,
        user: process.env.DB_USER,
        password: process.env.DB_PASSWORD,
        database: process.env.DB_DATABASE,
    },

    // JWT (JSON Web Token) configuration for authentication
    jwt: {
        secret: process.env.JWT_SECRET || 'aVeryStrongDefaultSecretKeyForJWTAuthentication', // IMPORTANT: Change this in production
        expiresIn: process.env.JWT_EXPIRES_IN || '1h', // Token expiration time
    },

    // Email service configuration for Nodemailer
    email: {
        host: process.env.EMAIL_HOST,
        port: parseInt(process.env.EMAIL_PORT, 10) || 587, // Default SMTP port
        secure: process.env.EMAIL_SECURE === 'true', // Use TLS (true for port 465, false for 587/25)
        user: process.env.EMAIL_USER,
        pass: process.env.EMAIL_PASS,
        from: process.env.EMAIL_FROM || '"Monitoring Tool" <no-reply@example.com>', // Sender email address
    },

    // SNMP (Simple Network Management Protocol) configuration for sending traps
    snmp: {
        receiverHost: process.env.SNMP_RECEIVER_HOST || '127.0.0.1', // IP of the SNMP trap receiver
        community: process.env.SNMP_COMMUNITY || 'public', // SNMP community string
    },

    // Specific OIDs (Object Identifiers) for different alert types
    // These are examples; define them according to your MIB (Management Information Base).
    alerting: {
        emailRecipient: process.env.ALERTING_EMAIL_RECIPIENT || 'admin@example.com', // Default email for alerts
        snmpApiDownOid: process.env.SNMP_API_DOWN_OID || '.1.3.6.1.4.1.9999.1.1', // OID for API down alerts
        snmpCertExpiryOid: process.env.SNMP_CERT_EXPIRY_OID || '.1.3.6.1.4.1.9999.1.2', // OID for certificate expiry alerts
        certWarningDays: parseInt(process.env.CERT_WARNING_DAYS, 10) || 30, // Days before expiry to send a warning
    }
};
