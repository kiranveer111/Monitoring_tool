// backend/src/jobs/monitorScheduler.js
const { getDB } = require('../db/connection');
const logger = require('../utils/logger');
const apiMonitorService = require('../services/apiMonitorService');
const certMonitorService = require('../services/certMonitorService');

// Store active intervals globally to manage them
global.monitoringIntervals = {};

/**
 * Initiates periodic monitoring for all active URLs.
 * This function should be called once when the application starts.
 */
async function startMonitoring() {
    const db = getDB();
    try {
        // Select all active URLs from the database
        const [urls] = await db.execute('SELECT * FROM MonitoredUrls WHERE is_active = TRUE');

        for (const url of urls) {
            scheduleMonitor(url); // Schedule each URL for monitoring
        }
    } catch (error) {
        logger.error(`Error starting global monitoring: ${error.message}`);
    }
}

/**
 * Schedules a single URL for monitoring based on its type and interval.
 * @param {object} urlObject - The URL object from the database.
 */
function scheduleMonitor(urlObject) {
    const { id: urlId, url, type, monitoring_interval_minutes } = urlObject;

    // Clear any existing interval for this URL first to prevent duplicates
    if (global.monitoringIntervals[urlId]) {
        clearInterval(global.monitoringIntervals[urlId]);
        logger.info(`Cleared existing monitor for URL ID: ${urlId}`);
    }

    // Determine which service to use based on URL type
    const checkFunction = type === 'API'
        ? apiMonitorService.checkApiUrlStatus
        : certMonitorService.checkCertStatus; // For 'DOMAIN' type, we're primarily interested in certs here

    // Immediately check status once when monitoring starts/restarts
    checkFunction(urlObject);

    // Set up interval for continuous monitoring
    const intervalInMs = monitoring_interval_minutes * 60 * 1000;
    const intervalId = setInterval(() => checkFunction(urlObject), intervalInMs);
    global.monitoringIntervals[urlId] = intervalId; // Store interval ID to clear later

    logger.info(`Monitoring scheduled for URL: ${url.name} (ID: ${urlId}, Type: ${type}) every ${monitoring_interval_minutes} minutes.`);
}

/**
 * Stops monitoring for a specific URL.
 * @param {number} urlId - The ID of the URL to stop monitoring.
 */
function stopMonitor(urlId) {
    if (global.monitoringIntervals && global.monitoringIntervals[urlId]) {
        clearInterval(global.monitoringIntervals[urlId]);
        delete global.monitoringIntervals[urlId];
        logger.info(`Monitoring stopped for URL ID: ${urlId}`);
    }
}

/**
 * Restarts monitoring for a specific URL (useful after update).
 * @param {object} urlObject - The updated URL object.
 */
function restartMonitor(urlObject) {
    if (urlObject.is_active) {
        scheduleMonitor(urlObject); // Reschedule if active
    } else {
        stopMonitor(urlObject.id); // Stop if marked inactive
        logger.info(`URL ID ${urlObject.id} is inactive, monitoring stopped.`);
    }
}

module.exports = {
    startMonitoring,
    scheduleMonitor,
    stopMonitor,
    restartMonitor
};
