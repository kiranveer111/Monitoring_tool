// backend/src/controllers/monitorController.js
const { getDB } = require('../db/connection');
const AppError = require('../utils/appError');
const logger = require('../utils/logger');
const monitorScheduler = require('../jobs/monitoringScheduler'); // FIX: Ensure this path is correct and the file exists

/**
 * Get all monitored URLs for the authenticated user.
 * Accessible by any authenticated user.
 */
exports.getUrls = async (req, res, next) => {
    const db = getDB();
    const userId = req.user.id; // Get user ID from authenticated request

    try {
        // Fetch URLs along with associated proxy details (if any)
        const [urls] = await db.execute(
            `SELECT mu.*, pc.name as proxy_name, pc.host as proxy_host, pc.port as proxy_port, pc.protocol as proxy_protocol
             FROM MonitoredUrls mu
             LEFT JOIN ProxyConfigurations pc ON mu.proxy_config_id = pc.id
             WHERE mu.user_id = ?`,
            [userId]
        );
        res.status(200).json({
            status: 'success',
            results: urls.length,
            data: {
                urls,
            },
        });
    } catch (error) {
        logger.error(`Error fetching URLs for user ${userId}: ${error.message}`);
        next(new AppError('Failed to retrieve URLs.', 500));
    }
};

/**
 * Add a new URL to be monitored.
 * Restricted to 'admin' role.
 */
exports.addUrl = async (req, res, next) => {
    const db = getDB();
    const userId = req.user.id; // Get user ID from authenticated request
    const { name, url, type, monitoring_interval_minutes, proxy_config_id, is_active } = req.body;

    // Basic validation
    if (!name || !url || !type || !monitoring_interval_minutes) {
        return next(new AppError('Missing required URL fields.', 400));
    }
    if (!['API', 'DOMAIN'].includes(type)) {
        return next(new AppError('Invalid URL type. Must be API or DOMAIN.', 400));
    }
    if (monitoring_interval_minutes < 1) {
        return next(new AppError('Monitoring interval must be at least 1 minute.', 400));
    }

    try {
        const [result] = await db.execute(
            `INSERT INTO MonitoredUrls
             (user_id, name, url, type, monitoring_interval_minutes, proxy_config_id, is_active)
             VALUES (?, ?, ?, ?, ?, ?, ?)`,
            [userId, name, url, type, monitoring_interval_minutes, proxy_config_id || null, is_active]
        );

        const newUrl = {
            id: result.insertId,
            user_id: userId,
            name,
            url,
            type,
            monitoring_interval_minutes,
            proxy_config_id,
            is_active
        };

        // If active, schedule it for monitoring
        if (is_active) {
            // Fetch the full URL object with proxy details for scheduling
            const [urls] = await db.execute(
                `SELECT mu.*, pc.name as proxy_name, pc.host as proxy_host, pc.port as proxy_port, pc.protocol as proxy_protocol
                 FROM MonitoredUrls mu
                 LEFT JOIN ProxyConfigurations pc ON mu.proxy_config_id = pc.id
                 WHERE mu.id = ?`,
                [newUrl.id]
            );
            if (urls.length > 0) {
                monitorScheduler.scheduleMonitor(urls[0]);
            }
        }

        res.status(201).json({
            status: 'success',
            message: 'URL added successfully.',
            data: {
                url: newUrl,
            },
        });
    } catch (error) {
        logger.error(`Error adding URL for user ${userId}: ${error.message}`);
        next(new AppError('Failed to add URL. Check if URL already exists or input is valid.', 500));
    }
};

/**
 * Update an existing monitored URL.
 * Restricted to 'admin' role.
 */
exports.updateUrl = async (req, res, next) => {
    const db = getDB();
    const userId = req.user.id;
    const urlId = req.params.id; // URL ID from parameters
    const { name, url, type, monitoring_interval_minutes, proxy_config_id, is_active } = req.body;

    // Basic validation
    if (!name || !url || !type || !monitoring_interval_minutes) {
        return next(new AppError('Missing required URL fields for update.', 400));
    }
    if (!['API', 'DOMAIN'].includes(type)) {
        return next(new AppError('Invalid URL type. Must be API or DOMAIN.', 400));
    }
    if (monitoring_interval_minutes < 1) {
        return next(new AppError('Monitoring interval must be at least 1 minute.', 400));
    }

    try {
        const [result] = await db.execute(
            `UPDATE MonitoredUrls SET
                name = ?,
                url = ?,
                type = ?,
                monitoring_interval_minutes = ?,
                proxy_config_id = ?,
                is_active = ?,
                updated_at = NOW()
             WHERE id = ? AND user_id = ?`,
            [name, url, type, monitoring_interval_minutes, proxy_config_id || null, is_active, urlId, userId]
        );

        if (result.affectedRows === 0) {
            return next(new AppError('URL not found or not authorized to update.', 404));
        }

        // Restart monitoring for this specific URL with updated settings
        // Fetch the updated full URL object with proxy details for scheduling
        const [urls] = await db.execute(
            `SELECT mu.*, pc.name as proxy_name, pc.host as proxy_host, pc.port as proxy_port, pc.protocol as proxy_protocol
             FROM MonitoredUrls mu
             LEFT JOIN ProxyConfigurations pc ON mu.proxy_config_id = pc.id
             WHERE mu.id = ?`,
            [urlId]
        );
        if (urls.length > 0) {
            monitorScheduler.restartMonitor(urls[0]);
        }

        res.status(200).json({
            status: 'success',
            message: 'URL updated successfully.',
        });
    } catch (error) {
        logger.error(`Error updating URL ID ${urlId} for user ${userId}: ${error.message}`);
        next(new AppError('Failed to update URL.', 500));
    }
};

/**
 * Delete a monitored URL.
 * Restricted to 'admin' role.
 */
exports.deleteUrl = async (req, res, next) => {
    const db = getDB();
    const userId = req.user.id;
    const urlId = req.params.id;

    try {
        const [result] = await db.execute(
            `DELETE FROM MonitoredUrls WHERE id = ? AND user_id = ?`,
            [urlId, userId]
        );

        if (result.affectedRows === 0) {
            return next(new AppError('URL not found or not authorized to delete.', 404));
        }

        // Stop monitoring for the deleted URL
        monitorScheduler.stopMonitor(urlId);

        res.status(204).json({ // 204 No Content for successful deletion
            status: 'success',
            data: null,
            message: 'URL deleted successfully.',
        });
    } catch (error) {
        logger.error(`Error deleting URL ID ${urlId} for user ${userId}: ${error.message}`);
        next(new AppError('Failed to delete URL.', 500));
    }
};

/**
 * Get monitoring logs for a specific URL.
 * Accessible by any authenticated user.
 */
exports.getMonitoringLogs = async (req, res, next) => {
    const db = getDB();
    const userId = req.user.id;
    const urlId = req.params.id;
    const limit = parseInt(req.query.limit || '100', 10); // Default limit to 100 logs

    try {
        // First, verify the URL belongs to the user
        const [urls] = await db.execute(
            `SELECT id FROM MonitoredUrls WHERE id = ? AND user_id = ?`,
            [urlId, userId]
        );

        if (urls.length === 0) {
            return next(new AppError('URL not found or not authorized.', 404));
        }

        // Fetch logs for the specified URL
        const [logs] = await db.execute(
            `SELECT * FROM MonitoringLogs WHERE url_id = ? ORDER BY checked_at DESC LIMIT ?`,
            [urlId, limit]
        );

        res.status(200).json({
            status: 'success',
            results: logs.length,
            data: {
                logs,
            },
        });
    } catch (error) {
        logger.error(`Error fetching logs for URL ID ${urlId} for user ${userId}: ${error.message}`);
        next(new AppError('Failed to retrieve monitoring logs.', 500));
    }
};

/**
 * Get certificate information for a specific URL.
 * Accessible by any authenticated user.
 */
exports.getCertificateInfo = async (req, res, next) => {
    const db = getDB();
    const userId = req.user.id;
    const urlId = req.params.id;

    try {
        // First, verify the URL belongs to the user and is a 'DOMAIN' type
        const [urls] = await db.execute(
            `SELECT id, type, certificate_status, days_remaining FROM MonitoredUrls WHERE id = ? AND user_id = ? AND type = 'DOMAIN'`,
            [urlId, userId]
        );

        if (urls.length === 0) {
            return next(new AppError('Certificate info not found or not authorized for this URL type.', 404));
        }

        res.status(200).json({
            status: 'success',
            data: {
                certificate: {
                    status: urls[0].certificate_status,
                    days_remaining: urls[0].days_remaining
                },
            },
        });
    } catch (error) {
        logger.error(`Error fetching certificate info for URL ID ${urlId} for user ${userId}: ${error.message}`);
        next(new AppError('Failed to retrieve certificate information.', 500));
    }
};


/**
 * Get all proxy configurations for the authenticated user.
 * Accessible by any authenticated user.
 */
exports.getProxyConfigs = async (req, res, next) => {
    const db = getDB();
    const userId = req.user.id;

    try {
        const [proxies] = await db.execute(
            `SELECT * FROM ProxyConfigurations WHERE user_id = ?`,
            [userId]
        );
        res.status(200).json({
            status: 'success',
            results: proxies.length,
            data: {
                proxyConfigs: proxies,
            },
        });
    } catch (error) {
        logger.error(`Error fetching proxy configs for user ${userId}: ${error.message}`);
        next(new AppError('Failed to retrieve proxy configurations.', 500));
    }
};

/**
 * Add a new proxy configuration.
 * Restricted to 'admin' role.
 */
exports.addProxyConfig = async (req, res, next) => {
    const db = getDB();
    const userId = req.user.id;
    const { name, host, port, protocol, username, password, enabled } = req.body;

    if (!name || !host || !port || !protocol) {
        return next(new AppError('Missing required proxy configuration fields.', 400));
    }

    try {
        const [result] = await db.execute(
            `INSERT INTO ProxyConfigurations
             (user_id, name, host, port, protocol, username, password, enabled)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
            [userId, name, host, port, protocol, username || null, password || null, enabled]
        );

        res.status(201).json({
            status: 'success',
            message: 'Proxy configuration added successfully.',
            data: {
                proxyConfig: { id: result.insertId, name, host, port, protocol, username, password, enabled },
            },
        });
    } catch (error) {
        logger.error(`Error adding proxy config for user ${userId}: ${error.message}`);
        next(new AppError('Failed to add proxy configuration.', 500));
    }
};

/**
 * Update an existing proxy configuration.
 * Restricted to 'admin' role.
 */
exports.updateProxyConfig = async (req, res, next) => {
    const db = getDB();
    const userId = req.user.id;
    const proxyId = req.params.id;
    const { name, host, port, protocol, username, password, enabled } = req.body;

    if (!name || !host || !port || !protocol) {
        return next(new AppError('Missing required proxy configuration fields for update.', 400));
    }

    try {
        const [result] = await db.execute(
            `UPDATE ProxyConfigurations SET
                name = ?,
                host = ?,
                port = ?,
                protocol = ?,
                username = ?,
                password = ?,
                enabled = ?,
                updated_at = NOW()
             WHERE id = ? AND user_id = ?`,
            [name, host, port, protocol, username || null, password || null, enabled, proxyId, userId]
        );

        if (result.affectedRows === 0) {
            return next(new AppError('Proxy configuration not found or not authorized to update.', 404));
        }

        res.status(200).json({
            status: 'success',
            message: 'Proxy configuration updated successfully.',
        });
    } catch (error) {
        logger.error(`Error updating proxy config ID ${proxyId} for user ${userId}: ${error.message}`);
        next(new AppError('Failed to update proxy configuration.', 500));
    }
};

/**
 * Delete a proxy configuration.
 * Restricted to 'admin' role.
 */
exports.deleteProxyConfig = async (req, res, next) => {
    const db = getDB();
    const userId = req.user.id;
    const proxyId = req.params.id;

    try {
        // Before deleting proxy config, ensure no URLs are using it
        const [urlsUsingProxy] = await db.execute(
            `SELECT COUNT(*) as count FROM MonitoredUrls WHERE proxy_config_id = ?`,
            [proxyId]
        );

        if (urlsUsingProxy[0].count > 0) {
            return next(new AppError('Cannot delete proxy configuration: it is currently in use by one or more monitored URLs.', 409)); // 409 Conflict
        }

        const [result] = await db.execute(
            `DELETE FROM ProxyConfigurations WHERE id = ? AND user_id = ?`,
            [proxyId, userId]
        );

        if (result.affectedRows === 0) {
            return next(new AppError('Proxy configuration not found or not authorized to delete.', 404));
        }

        res.status(204).json({ // 204 No Content
            status: 'success',
            data: null,
            message: 'Proxy configuration deleted successfully.',
        });
    } catch (error) {
        logger.error(`Error deleting proxy config ID ${proxyId} for user ${userId}: ${error.message}`);
        next(new AppError('Failed to delete proxy configuration.', 500));
    }
};
