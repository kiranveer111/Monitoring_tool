const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const ldap = require('ldapjs');
const { getDB } = require('../db/connection');
const { validateRegister, validateLogin } = require('../utils/validation');
const AppError = require('../utils/appError');
const config = require('../config');
console.log('🛠 LDAP CONFIG:', config.ldap);
const logger = require('../utils/logger');

/**
 * Register a local user
 */
exports.register = async (req, res, next) => {
  try {
    const { error } = validateRegister(req.body);
    if (error) return next(new AppError(error.details[0].message, 400));

    const { username, email, password } = req.body;
    const hashedPassword = await bcrypt.hash(password, 12);
    const db = getDB();

    await db.execute(
      `INSERT INTO Users (username, email, password, role) VALUES (?, ?, ?, ?)`,
      [username, email, hashedPassword, 'user']
    );

    logger.info(`New user registered: ${username}`);
    res.status(201).json({ message: 'User registered successfully.' });
  } catch (err) {
    logger.error('Registration error:', err);
    next(new AppError('User registration failed', 500));
  }
};

/**
 * Login with local DB or fallback to LDAP
 */
console.log('Loaded LDAP Config:', config.ldap);
exports.login = async (req, res, next) => {
  try {
    const { error } = validateLogin(req.body);
    if (error) return next(new AppError(error.details[0].message, 400));

    const { username, password } = req.body;
    const db = getDB();

    // Step 1: Try local DB login
    const [rows] = await db.execute('SELECT * FROM Users WHERE username = ?', [username]);
    const user = rows[0];

    if (user && user.password !== 'ldap-user') {
      const isMatch = await bcrypt.compare(password, user.password);
      if (isMatch) {
        const token = jwt.sign({ id: user.id, username: user.username, role: user.role }, config.jwt.secret, {
          expiresIn: config.jwt.expiresIn || '1d'
        });
        logger.info(`Local login successful for ${username}`);
        return res.status(200).json({ message: 'Logged in successfully (local)', token });
      }
    }

    // Step 2: Try LDAP bind search → authenticate
    const client = ldap.createClient({
      url: config.ldap.url,
      tlsOptions: {
        rejectUnauthorized: false // Accept self-signed for now; secure in prod
      }
    });

    const searchOptions = {
      scope: 'sub',
      filter: `(${config.ldap.usernameField}=${username})`
    };

    client.bind(config.ldap.bindDN, config.ldap.bindPassword, (bindErr) => {
      if (bindErr) {
        logger.warn(`LDAP bind failed: ${bindErr.message}`);
        return next(new AppError('LDAP bind failed', 401));
      }

      client.search(config.ldap.baseDN, searchOptions, async (err, resSearch) => {
        if (err) {
          logger.error(`LDAP search failed for ${username}: ${err.message}`);
          return next(new AppError('LDAP search failed', 401));
        }

        let userDN = null;

        resSearch.on('searchEntry', (entry) => {
          userDN = entry.objectName;
        });

        resSearch.on('end', async () => {
          if (!userDN) {
            logger.warn(`LDAP user not found: ${username}`);
            return next(new AppError('User not found in AD', 401));
          }

          // Attempt to bind with user's DN and input password
          client.bind(userDN, password, async (authErr) => {
            if (authErr) {
              logger.warn(`LDAP auth failed for ${username}: ${authErr.message}`);
              return next(new AppError('Invalid credentials', 401));
            }

            logger.info(`LDAP login successful for user: ${username}`);

            // Sync user to local DB (if not already present)
            if (!user) {
              await db.execute(
                `INSERT INTO Users (username, email, password, role) VALUES (?, ?, ?, ?)`,
                [username, `${username}@yourdomain.com`, 'ldap-user', 'user']
              );
              logger.info(`LDAP user ${username} synced to DB`);
            }

            const [newRows] = await db.execute('SELECT * FROM Users WHERE username = ?', [username]);
            const ldapUser = newRows[0];

            const token = jwt.sign(
              { id: ldapUser.id, username: ldapUser.username, role: ldapUser.role },
              config.jwt.secret,
              { expiresIn: config.jwt.expiresIn || '1d' }
            );

            client.unbind();
            return res.status(200).json({ message: 'Logged in successfully (LDAP)', token });
          });
        });
      });
    });
  } catch (err) {
    logger.error('Login error:', err);
    next(new AppError('Login failed', 500));
  }
};

/**
 * Get authenticated user's profile
 */
exports.getMe = async (req, res, next) => {
  try {
    const db = getDB();
    const [rows] = await db.execute('SELECT id, username, email, role FROM Users WHERE id = ?', [req.user.id]);

    if (rows.length === 0) {
      return next(new AppError('User not found', 404));
    }

    res.status(200).json({ user: rows[0] });
  } catch (err) {
    logger.error('GetMe error:', err);
    next(new AppError('Failed to get user info', 500));
  }
};
