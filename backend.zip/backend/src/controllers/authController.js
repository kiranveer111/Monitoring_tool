// backend/src/controllers/authController.js
const authService = require('../services/authService');
const AppError = require('../utils/appError');
const logger = require('../utils/logger');

/**
 * Handles user registration.
 */
exports.register = async (req, res, next) => {
    try {
        const { username, email, password } = req.body;

        if (!username || !email || !password) {
            return next(new AppError('Please provide username, email, and password for registration.', 400));
        }

        const newUser = await authService.registerUser(username, email, password);

        // Optionally, you might want to auto-login the user after registration
        // For now, just send a success message. User will need to login separately.
        res.status(201).json({
            status: 'success',
            message: 'User registered successfully. Please log in.',
            data: {
                user: {
                    id: newUser.id,
                    username: newUser.username,
                    email: newUser.email,
                    role: newUser.role // Include role if returned
                }
            }
        });
    } catch (error) {
        logger.error(`Registration error: ${error.message}`);
        next(error); // Pass error to global error handler
    }
};

/**
 * Handles user login and generates a JWT.
 */
exports.login = async (req, res, next) => {
    try {
        const { username, password } = req.body;

        if (!username || !password) {
            return next(new AppError('Please provide username and password for login.', 400));
        }

        const { token, user } = await authService.loginUser(username, password);

        res.status(200).json({
            status: 'success',
            message: 'Logged in successfully',
            token,
            user // This now correctly includes the role from authService.loginUser
        });
    } catch (error) {
        logger.error(`Login error: ${error.message}`);
        next(error); // Pass error to global error handler
    }
};

/**
 * Get current authenticated user's details.
 * This function should be protected by authMiddleware.protect
 * The user object is attached to req.user by the protect middleware.
 */
exports.getMe = (req, res, next) => {
    // req.user contains the user data attached by the authMiddleware.protect
    if (!req.user) {
        return next(new AppError('User not authenticated.', 401));
    }

    res.status(200).json({
        status: 'success',
        data: {
            user: {
                id: req.user.id,
                username: req.user.username,
                email: req.user.email,
                role: req.user.role // Ensure role is returned for the frontend
            }
        }
    });
};

// You can add more controller methods here, e.g., for user management by admin
/*
exports.createUser = async (req, res, next) => {
    try {
        // Example: Only an admin can create other users (with default 'user' role)
        if (req.user.role !== 'admin') {
            return next(new AppError('Only administrators can create new users.', 403));
        }

        const { username, email, password, role = 'user' } = req.body; // Default role to 'user'

        if (!username || !email || !password) {
            return next(new AppError('Please provide username, email, and password.', 400));
        }

        const newUser = await authService.registerUser(username, email, password, role); // Pass role

        res.status(201).json({
            status: 'success',
            message: 'New user created successfully.',
            data: { user: newUser }
        });
    } catch (error) {
        logger.error(`Admin user creation error: ${error.message}`);
        next(error);
    }
};
*/
