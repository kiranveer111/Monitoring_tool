// backend/src/controllers/alertController.js
const { getDB } = require('../db/connection');
const AppError = require('../utils/appError');
const logger = require('../utils/logger');
const config = require('../config'); // To update runtime config

/**
 * Get alert configuration for the authenticated user.
 * Restricted to 'admin' role.
 */
exports.getAlertConfig = async (req, res, next) => {
    const db = getDB();
    const userId = req.user.id;

    try {
        const [configs] = await db.execute(
            `SELECT * FROM AlertConfigurations WHERE user_id = ?`,
            [userId]
        );

        let alertConfig = configs[0] || {}; // Return existing config or empty object

        // Merge with default values from config if not present in DB
        alertConfig = {
            email_recipient: alertConfig.email_recipient || '',
            snmp_receiver_host: alertConfig.snmp_receiver_host || '',
            snmp_community: alertConfig.snmp_community || '',
            snmp_api_down_oid: alertConfig.snmp_api_down_oid || '',
            snmp_cert_expiry_oid: alertConfig.snmp_cert_expiry_oid || '',
            cert_warning_days: alertConfig.cert_warning_days || config.alert.certWarningDays,
            // Include ID if exists for updates
            id: alertConfig.id || null
        };

        res.status(200).json({
            status: 'success',
            data: {
                alertConfig,
            },
        });
    } catch (error) {
        logger.error(`Error fetching alert config for user ${userId}: ${error.message}`);
        next(new AppError('Failed to retrieve alert configuration.', 500));
    }
};

/**
 * Save (create or update) alert configuration for the authenticated user.
 * Restricted to 'admin' role.
 */
exports.saveAlertConfig = async (req, res, next) => {
    const db = getDB();
    const userId = req.user.id;
    const {
        email_recipient,
        snmp_receiver_host,
        snmp_community,
        snmp_api_down_oid,
        snmp_cert_expiry_oid,
        cert_warning_days
    } = req.body;

    // Basic validation
    if (!email_recipient && !snmp_receiver_host) {
        return next(new AppError('At least an email recipient or SNMP receiver host is required.', 400));
    }
    if (cert_warning_days < 1 || cert_warning_days > 365) {
        return next(new AppError('Certificate warning days must be between 1 and 365.', 400));
    }

    try {
        // Check if an existing configuration exists for this user
        const [existingConfigs] = await db.execute(
            `SELECT id FROM AlertConfigurations WHERE user_id = ?`,
            [userId]
        );

        if (existingConfigs.length > 0) {
            // Update existing configuration
            const configId = existingConfigs[0].id;
            await db.execute(
                `UPDATE AlertConfigurations SET
                    email_recipient = ?,
                    snmp_receiver_host = ?,
                    snmp_community = ?,
                    snmp_api_down_oid = ?,
                    snmp_cert_expiry_oid = ?,
                    cert_warning_days = ?,
                    updated_at = NOW()
                 WHERE id = ? AND user_id = ?`,
                [email_recipient || null, snmp_receiver_host || null, snmp_community || null,
                 snmp_api_down_oid || null, snmp_cert_expiry_oid || null, cert_warning_days,
                 configId, userId]
            );
            // Optionally, update the runtime config if relevant (e.g., cert_warning_days)
            config.alert.certWarningDays = cert_warning_days; // Update runtime config
            res.status(200).json({
                status: 'success',
                message: 'Alert configuration updated successfully.',
            });
        } else {
            // Insert new configuration
            const [result] = await db.execute(
                `INSERT INTO AlertConfigurations
                 (user_id, email_recipient, snmp_receiver_host, snmp_community,
                  snmp_api_down_oid, snmp_cert_expiry_oid, cert_warning_days)
                 VALUES (?, ?, ?, ?, ?, ?, ?)`,
                [userId, email_recipient || null, snmp_receiver_host || null, snmp_community || null,
                 snmp_api_down_oid || null, snmp_cert_expiry_oid || null, cert_warning_days]
            );
            // Optionally, update the runtime config if relevant
            config.alert.certWarningDays = cert_warning_days; // Update runtime config
            res.status(201).json({
                status: 'success',
                message: 'Alert configuration created successfully.',
                data: { id: result.insertId }
            });
        }
    } catch (error) {
        logger.error(`Error saving alert config for user ${userId}: ${error.message}`);
        next(new AppError('Failed to save alert configuration.', 500));
    }
};
