// backend/src/services/certMonitorService.js
const https = require('https');
const { getDB } = require('../db/connection');
const logger = require('../utils/logger');
const config = require('../config');
const notificationService = require('./notificationService'); // For sending alerts

/**
 * Checks the SSL/TLS certificate status for a given domain URL.
 * @param {object} urlObject - The URL object from the database, specifically for type 'DOMAIN'.
 */
async function checkCertStatus(urlObject) {
    const { id: urlId, url, name, user_id } = urlObject;
    let certificateStatus = null; // 'valid', 'warning', 'expired', 'unavailable', 'error', 'not_reachable'
    let daysRemaining = null;

    // Only proceed if the URL is HTTPS
    if (!url.startsWith('https://')) {
        certificateStatus = 'not_applicable';
        logger.info(`URL ID ${urlId} (${name}) is not HTTPS, skipping certificate check.`);
        return; // Exit early if not HTTPS
    }

    try {
        const hostname = new URL(url).hostname;

        const certCheckPromise = new Promise((resolve, reject) => {
            const req = https.request({
                hostname: hostname,
                port: 443,
                method: 'HEAD', // Use HEAD to minimize data transfer
                rejectUnauthorized: false // Allow self-signed certs for inspection, don't fail connection
            }, (res) => {
                const cert = res.socket.getPeerCertificate(); // Get the certificate object from the socket

                if (cert && cert.valid_to) {
                    const expiryDate = new Date(cert.valid_to);
                    const now = new Date();
                    const diffTime = expiryDate.getTime() - now.getTime();
                    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24)); // Convert to days

                    daysRemaining = diffDays;

                    if (expiryDate < now) {
                        certificateStatus = 'expired';
                        logger.warn(`Cert for ${name} (${url}) is EXPIRED. Days remaining: ${daysRemaining}.`);
                        notificationService.sendCertExpiryAlert(urlObject, 'expired', daysRemaining);
                    } else if (diffDays <= config.alert.certWarningDays) {
                        certificateStatus = 'warning';
                        logger.warn(`Cert for ${name} (${url}) is WARNING. Days remaining: ${daysRemaining}.`);
                        notificationService.sendCertExpiryAlert(urlObject, 'warning', daysRemaining);
                    } else {
                        certificateStatus = 'valid';
                        logger.info(`Cert for ${name} (${url}) is VALID. Days remaining: ${daysRemaining}.`);
                    }
                } else {
                    certificateStatus = 'unavailable'; // No valid certificate found or parsable
                    logger.warn(`Cert for ${name} (${url}) is UNAVAILABLE or could not be parsed.`);
                    notificationService.sendCertExpiryAlert(urlObject, 'unavailable');
                }
                res.resume(); // Consume response data to prevent memory leaks
                resolve();
            });

            req.on('error', (e) => {
                logger.error(`Certificate check network error for ${url}: ${e.message}`);
                certificateStatus = 'not_reachable'; // Network error during cert check (e.g., host unreachable)
                daysRemaining = null;
                notificationService.sendCertExpiryAlert(urlObject, 'error', null, e.message);
                reject(e); // Reject the promise on network errors
            });

            req.end(); // End the request
        });

        await certCheckPromise.catch(certError => {
            // Catching rejections from the certCheckPromise to ensure the main flow continues
            logger.error(`Promise rejection during cert check for ${url}: ${certError.message}`);
            // If certificateStatus was already set by req.on('error'), keep it.
            // Otherwise, set a general error.
            if (!certificateStatus) {
                certificateStatus = 'error';
                daysRemaining = null;
            }
        });

    } catch (error) {
        logger.error(`Error during HTTPS certificate check for ${url}: ${error.message}`);
        certificateStatus = 'error'; // Broader error during cert check process
        daysRemaining = null;
        notificationService.sendCertExpiryAlert(urlObject, 'error', null, error.message);
    }

    // Update the database with the certificate information
    const db = getDB();
    try {
        await db.execute(
            `UPDATE MonitoredUrls SET
                certificate_status = ?,
                days_remaining = ?
             WHERE id = ?`,
            [certificateStatus, daysRemaining, urlId]
        );
        logger.info(`URL ID ${urlId} (${name}) certificate status updated to: ${certificateStatus || 'N/A'}, Days Remaining: ${daysRemaining || 'N/A'}`);
    } catch (dbError) {
        logger.error(`Error updating certificate info in database for URL ID ${urlId}: ${dbError.message}`);
    }
}

module.exports = {
    checkCertStatus
};
