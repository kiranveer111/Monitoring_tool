// backend/src/services/apiMonitorService.js
const axios = require('axios');
const { getDB } = require('../db/connection');
const logger = require('../utils/logger');
const notificationService = require('./notificationService'); // For sending alerts

/**
 * Checks the status of an API URL.
 * Determines 'up' or 'down' based on HTTP status codes (2xx, 3xx, 4xx are up).
 * @param {object} urlObject - The URL object from the database.
 */
async function checkApiUrlStatus(urlObject) {
    const { id: urlId, url, name, user_id, proxy_config_id } = urlObject;
    let status = 'down'; // Default status
    let latency = null;
    const startTime = process.hrtime.bigint(); // High-resolution time for latency calculation

    try {
        // Axios configuration for handling various response statuses
        // We set validateStatus to always return true so we can process
        // all responses (including 4xx and 5xx) to determine 'up'/'down'
        const axiosConfig = {
            validateStatus: () => true, // Accept all status codes
            timeout: 15000, // 15-second timeout for API checks
            headers: {
                'User-Agent': 'MonitoringTool/1.0 (API-Monitor)'
            }
        };

        // TODO: Implement proxy integration here if proxy_config_id is present.
        // This would involve fetching proxy details from the DB and configuring axios with an agent.
        if (proxy_config_id) {
            logger.warn(`API monitoring for URL ID ${urlId} has a proxy configured but proxy integration is not fully implemented.`);
        }

        const response = await axios.get(url, axiosConfig);
        const endTime = process.hrtime.bigint();
        latency = Number(endTime - startTime) / 1_000_000; // Convert nanoseconds to milliseconds

        // Determine status based on HTTP response code
        if (response.status >= 200 && response.status < 500) {
            status = 'up'; // 2xx, 3xx, 4xx are considered 'up'
        } else {
            status = 'down'; // 5xx or other unexpected HTTP statuses
            logger.warn(`API ${name} (${url}) returned status ${response.status}. Marking as DOWN.`);
            // Potentially send an alert for 5xx errors
            notificationService.sendApiDownAlert(urlObject, response.status);
        }

    } catch (error) {
        // This catch block handles network errors (e.g., DNS resolution failure, connection refused, timeout)
        logger.error(`Network or unexpected error checking API URL ${url}: ${error.message}`);
        status = 'down';
        latency = null; // No meaningful latency on network failure
        notificationService.sendApiDownAlert(urlObject, null, error.message); // Send alert for network errors
    }

    // Update the database with the new status and latency
    const db = getDB();
    try {
        await db.execute(
            `UPDATE MonitoredUrls SET
                last_status = ?,
                last_checked_at = NOW(),
                last_latency = ?
             WHERE id = ?`,
            [status, latency, urlId]
        );
        logger.info(`API URL ID ${urlId} (${name}) status updated to: ${status}, Latency: ${latency ? latency.toFixed(2) + 'ms' : 'N/A'}`);
    } catch (dbError) {
        logger.error(`Error updating database for API URL ID ${urlId}: ${dbError.message}`);
    }
}

module.exports = {
    checkApiUrlStatus
};
